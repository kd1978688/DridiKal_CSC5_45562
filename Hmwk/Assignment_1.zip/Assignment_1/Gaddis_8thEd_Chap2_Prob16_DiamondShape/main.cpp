/* 
 * File:   main.cpp
 * Author: Kal Dridi
 * Created on June 08, 2017, 09:53 PM
 * Purpose:  Program to be utilized to show a Triangle
 *           Pattern on the compute screen.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    
    //Initialize variables
    
    //Input data
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout <<"    *   "<< endl;
    cout <<"   ***  "<< endl;
    cout <<"  ***** "<< endl;
    cout <<" ******* "<< endl;
    cout <<"*********"<< endl;
   
    //Exit stage right!
    return 0;
}

