/* 
 * File:   main.cpp
 * Author: Kal Dridi
 * Created on June 16, 2017, 9:57 PM
 * Purpose:  Program that displays personal 
 *           Information.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    
    //Initialize variables
    
    //Input data
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout << "Kal Dridi\n2460 Valencia Ave San Bernardino, CA 92404\n9096779689\n"
            "Chemical Engineering\n";
    
    
    //Exit stage right!
    return 0;
}

